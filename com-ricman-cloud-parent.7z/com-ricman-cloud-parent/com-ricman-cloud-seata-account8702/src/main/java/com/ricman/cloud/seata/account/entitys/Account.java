package com.ricman.cloud.seata.account.entitys;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author m93349
 * @Date 2020/10/26 8:44
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Account {
    private int Id;
    private int UserId;
    private long total;
    private long used;
    private long residue;
}
