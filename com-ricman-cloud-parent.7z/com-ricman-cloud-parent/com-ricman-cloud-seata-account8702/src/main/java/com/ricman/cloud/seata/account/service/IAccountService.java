package com.ricman.cloud.seata.account.service;

import com.ricman.cloud.seata.account.entitys.Account;

/**
 * @Author m93349
 * @Date 2020/10/26 10:54
 * @Version 1.0
 */
public interface IAccountService {
    public int decrease(int useId, int count);
    public Account selectById(int id);
}
