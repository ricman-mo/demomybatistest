package com.ricman.cloud.seata.account.controller;

import com.ricman.cloud.seata.account.entitys.Account;
import com.ricman.cloud.seata.account.entitys.CommonResult;
import com.ricman.cloud.seata.account.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/26 10:53
 * @Version 1.0
 */
@RestController
public class AccountController {

    @Autowired
    private IAccountService accountService;

    @GetMapping("account/decrease")
    public CommonResult<Account> decrease(@RequestParam("userId") int userId, @RequestParam("moneny")int moneny) {
        accountService.decrease(userId, moneny);
        return new CommonResult<Account>(200, "扣减成功！");
    }
}
