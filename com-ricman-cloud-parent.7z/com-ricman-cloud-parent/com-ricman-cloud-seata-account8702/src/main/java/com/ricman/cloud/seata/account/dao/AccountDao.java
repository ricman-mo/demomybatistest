package com.ricman.cloud.seata.account.dao;

import com.ricman.cloud.seata.account.entitys.Account;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author m93349
 * @Date 2020/10/26 10:53
 * @Version 1.0
 */
@Mapper
public interface AccountDao {
    public int decrease(int useId, int count);
    public Account selectById(int id);
}
