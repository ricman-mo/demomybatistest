package com.ricman.cloud.seata.account.service.impl;

import com.ricman.cloud.seata.account.dao.AccountDao;
import com.ricman.cloud.seata.account.entitys.Account;
import com.ricman.cloud.seata.account.service.IAccountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Author m93349
 * @Date 2020/10/26 11:03
 * @Version 1.0
 */
@Service
@Slf4j
public class AccountServiceImpl implements IAccountService {

    @Resource
    private AccountDao accountDao;

    public int decrease(int useId, int count) {
        Account account = selectById(useId);
        if(account.getResidue() < count) {
            throw  new RuntimeException("金额不足！");
        }
        return accountDao.decrease(useId, count);
    }

    public Account selectById(int id) {
        return accountDao.selectById(id);
    }
}
