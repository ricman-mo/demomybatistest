package com.ricman.cloud.controller;

import com.ricman.cloud.entitys.CommonResult;
import com.ricman.cloud.entitys.Playment;
import com.ricman.cloud.service.IPlaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/15 9:57
 * @Version 1.0
 */
@RestController
public class OrderController {
    @Autowired
    private IPlaymentService playmentService;

    @GetMapping("/playment/create")
    public CommonResult<?> CreatePlayment(@RequestBody Playment playment) {
        return playmentService.CreatePlayment(playment);
    }

    @GetMapping("/playment/get/{id}")
    public CommonResult<?> getPlayment(@PathVariable("id") int id) {
        return playmentService.GetPlaymentById(id);
    }
}