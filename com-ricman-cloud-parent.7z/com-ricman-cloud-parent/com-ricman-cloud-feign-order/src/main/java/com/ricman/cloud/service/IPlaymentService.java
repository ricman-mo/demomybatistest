package com.ricman.cloud.service;

import com.ricman.cloud.entitys.CommonResult;
import com.ricman.cloud.entitys.Playment;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @Author m93349
 * @Date 2020/10/15 9:52
 * @Version 1.0
 */
@Component
@FeignClient(value = "COM-RICMAN-CLOUD-PROVIDER",contextId = "PlaymentService")
public interface IPlaymentService {

    @GetMapping(value = "/playment/create")
    public CommonResult<Playment> CreatePlayment(@RequestBody Playment playment);

    @GetMapping(value = "/playment/get/{id}")
    public CommonResult<Object> GetPlaymentById(@PathVariable("id") int Id);

}
