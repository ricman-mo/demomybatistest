package com.ricman.cloud.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @Author m93349
 * @Date 2020/10/15 10:12
 * @Version 1.0
 */
@Component
@FeignClient(value = "COM-RICMAN-CLOUD-PROVIDER", contextId = "HelloService")
public interface IHelloService {

    @GetMapping("/hello")
    public String SayHello() ;
    @GetMapping("/longtime")
    public String TestTimeout() ;
}
