package com.ricman.cloud.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import sun.rmi.runtime.Log;

/**
 * @Author m93349
 * @Date 2020/10/15 10:34
 * @Version 1.0
 */
@Configuration
public class OpenfeignConfig {
    @Bean
    Logger.Level feignLogLevel() {
        return Logger.Level.FULL;
    }
}
