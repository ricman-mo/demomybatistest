package com.ricman.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author m93349
 * @Date 2020/10/20 14:53
 * @Version 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class NacosComsumerApplication8701 {
    public static void main(String[] args) {
        SpringApplication.run(NacosComsumerApplication8701.class, args);
    }
}
