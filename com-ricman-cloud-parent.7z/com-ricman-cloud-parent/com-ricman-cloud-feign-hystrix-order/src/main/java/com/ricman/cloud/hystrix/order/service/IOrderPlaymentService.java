package com.ricman.cloud.hystrix.order.service;

import com.ricman.cloud.hystrix.order.service.Impl.OrderFallBackService;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @Author m93349
 * @Date 2020/10/15 14:59
 * @Version 1.0
 */
@Service
@FeignClient(value = "COM-RICMAN-CLOUD-HYSTRIX-PROVIDER", fallback = OrderFallBackService.class)
public interface IOrderPlaymentService {

    @GetMapping("/playment/hystrix/ok/{id}")
    public String GetOk(@PathVariable("id") int id);

    @GetMapping("/playment/hystrix/timeout/{id}")
    public String GetTimeOut(@PathVariable("id") int id);
}
