package com.ricman.cloud.hystrix.order.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/15 15:39
 * @Version 1.0
 */
@RestController
public class HelleController {
    @GetMapping("/hello")
    public String test() {
        return  "Hello Ricman";
    }
}
