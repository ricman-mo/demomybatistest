package com.ricman.cloud.hystrix.order.controller;


import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.ricman.cloud.hystrix.order.service.IOrderPlaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/15 15:02
 * @Version 1.0
 */
@RestController
public class PlaymentController {

    @Autowired
    private IOrderPlaymentService orderPlaymentService;

    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/order/playment/hystrix/ok/{id}")
    public String GetOk(@PathVariable("id") int id) {
        System.out.println("get OK" + serverPort + "Thread " + Thread.currentThread().getName() + "ID " + id);
        return orderPlaymentService.GetOk(id);
    }

    @GetMapping("/order/playment/hystrix/timeout/{id}")
    @HystrixCommand(fallbackMethod = "GetTimeoutHandler", commandProperties = {
            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "3000")
    })
    public String GetTimeOut(@PathVariable("id") int id) {
        System.out.println("get GetTimeOut" + serverPort + "Thread " + Thread.currentThread().getName() + "ID " + id);
        return orderPlaymentService.GetTimeOut(id);
    }

    public String GetTimeoutHandler(int id) {
        return "请求繁忙，请稍后再试!";
    }
}
