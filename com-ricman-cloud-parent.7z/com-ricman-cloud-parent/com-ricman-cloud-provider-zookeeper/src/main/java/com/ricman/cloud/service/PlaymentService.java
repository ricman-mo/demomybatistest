package com.ricman.cloud.service;

import com.ricman.cloud.entitys.Playment;

public interface PlaymentService {
    public int create(Playment playment);

    public Playment getPlaymentById( long id);
}