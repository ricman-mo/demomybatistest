package com.ricman.cloud.service.Impl;

import com.ricman.cloud.dao.PlaymentDao;
import com.ricman.cloud.entitys.Playment;
import com.ricman.cloud.service.PlaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlaymentServiceImpl implements PlaymentService {
    @Autowired
    private PlaymentDao dao;
    public int create(Playment playment) {
        return dao.create(playment);
    }

    public Playment getPlaymentById(long id) {
        return dao.getPlaymentById(id);
    }
}