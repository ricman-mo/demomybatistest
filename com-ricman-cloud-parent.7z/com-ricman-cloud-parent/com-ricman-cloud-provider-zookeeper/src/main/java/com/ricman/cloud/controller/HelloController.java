package com.ricman.cloud.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/test")
    public String SayHello() {
        System.out.println("get from 8002");
        return  "Hello ricman";
    }
}

