package com.ricman.irule;

import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RandomRule;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author m93349
 * @Date 2020/10/14 16:47
 * @Version 1.0
 */
@Configuration
public class RibbonCustomRule {

    @Bean
    public IRule getRule() {
        return new RandomRule();
    }

}
