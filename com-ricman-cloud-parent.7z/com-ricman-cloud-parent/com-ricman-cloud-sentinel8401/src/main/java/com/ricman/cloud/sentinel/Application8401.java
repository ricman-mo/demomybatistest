package com.ricman.cloud.sentinel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author m93349
 * @Date 2020/10/21 16:12
 * @Version 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class Application8401 {
    public static void main(String[] args) {
        SpringApplication.run(Application8401.class, args);
    }
}
