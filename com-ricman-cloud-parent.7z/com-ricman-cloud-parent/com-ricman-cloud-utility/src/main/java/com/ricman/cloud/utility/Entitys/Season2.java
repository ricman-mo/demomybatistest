package com.ricman.cloud.utility.Entitys;

/**
 * @Author m93349
 * @Date 2020/10/22 13:16
 * @Version 1.0
 */
public class Season2 {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    private String name;
    private String desc;
    public Season2(String name, String desc) {
        this.name = name;
        this.desc   = desc;
    }

    @Override
    public String toString() {
        return  this.name + ": " +  this.desc ;
    }
}
