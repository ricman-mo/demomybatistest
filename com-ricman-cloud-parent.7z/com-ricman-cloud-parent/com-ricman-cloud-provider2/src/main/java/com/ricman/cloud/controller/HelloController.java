package com.ricman.cloud.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String SayHello() {
        System.out.println("get from 8002");
        return  "Hello ricman";
    }

    @GetMapping("/longtime")
    public String TestTimeout() {
        System.out.println("sleeping 3 s");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return  "3000 waiting";
    }
}

