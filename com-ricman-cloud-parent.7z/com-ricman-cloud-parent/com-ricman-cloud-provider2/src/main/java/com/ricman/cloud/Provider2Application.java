package com.ricman.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author m93349
 * @Date 2020/10/14 8:56
 * @Version 1.0
 */
@SpringBootApplication
public class Provider2Application {
    public static void main(String[] args) {
        SpringApplication.run(Provider2Application.class, args);
    }
}
