package com.ricman.cloud.seata.entitys;

import jdk.nashorn.internal.objects.annotations.Constructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author m93349
 * @Date 2020/10/23 13:33
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {
    private long Id;
    private int userId;
    private int productId;
    private int count;
    private double money;
    private int status;
}
