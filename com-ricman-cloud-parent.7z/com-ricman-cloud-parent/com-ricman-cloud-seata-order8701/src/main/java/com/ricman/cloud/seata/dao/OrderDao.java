package com.ricman.cloud.seata.dao;

import com.ricman.cloud.seata.entitys.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Author m93349
 * @Date 2020/10/23 13:43
 * @Version 1.0
 */
@Mapper
public interface OrderDao {
    void Create(Order order);

    void UpdateOrderStatus(@Param("userid")long userId, @Param("status")long status);
}
