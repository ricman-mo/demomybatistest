package com.ricman.cloud.seata.product.dao;

import com.ricman.cloud.seata.product.entitys.Product;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author m93349
 * @Date 2020/10/26 10:13
 * @Version 1.0
 */
@Mapper
public interface ProductDao {
    public void decrease(int id, long count);

    public Product selectById(int id);

    public int create(Product product);
}
