package com.ricman.cloud.seata.product.service;

import com.ricman.cloud.seata.product.entitys.Product;

/**
 * @Author m93349
 * @Date 2020/10/26 9:43
 * @Version 1.0
 */
public interface IProductService {

    public void decrease(int id, long number);

    public Product selectById(int id);

    public int create(Product product);

}
