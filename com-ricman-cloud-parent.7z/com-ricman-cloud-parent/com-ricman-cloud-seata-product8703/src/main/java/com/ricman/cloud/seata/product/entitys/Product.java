package com.ricman.cloud.seata.product.entitys;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author m93349
 * @Date 2020/10/26 8:36
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    private int Id;
    private long total;
    private long used;
    private long residue;

}
