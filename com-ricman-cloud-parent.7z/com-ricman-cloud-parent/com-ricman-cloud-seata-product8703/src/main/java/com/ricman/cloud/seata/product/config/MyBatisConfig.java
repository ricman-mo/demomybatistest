package com.ricman.cloud.seata.product.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @Author m93349
 * @Date 2020/10/23 14:30
 * @Version 1.0
 */
@Configuration
@MapperScan("com.ricman.cloud.seata.dao")
public class MyBatisConfig {
}

