package com.ricman.cloud.seata.product.service.Impl;

import com.ricman.cloud.seata.product.dao.ProductDao;
import com.ricman.cloud.seata.product.entitys.Product;
import com.ricman.cloud.seata.product.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Author m93349
 * @Date 2020/10/26 10:28
 * @Version 1.0
 */
@Service
public class ProductServiceImpl implements IProductService {

    @Resource
    private ProductDao dao;

    public void decrease(int id, long number) {
        dao.decrease(id, number);
    }

    public Product selectById(int id) {
        return dao.selectById(id);
    }

    public int create(Product product) {
        return dao.create(product);
    }
}
