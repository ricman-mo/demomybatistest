package com.ricman.cloud.controller;

import com.ricman.cloud.entitys.CommonResult;
import com.ricman.cloud.entitys.Playment;
import com.ricman.cloud.service.PlaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.*;

@RestController
public class PlaymentController {
    @Autowired
    private PlaymentService playmentService;

    @Autowired
    private DiscoveryClient discoveryClient;

    @Value("${server.port}")
    private String serverPort;

    @GetMapping(value = "/playment/get/{id}")
    public CommonResult<Object> GetPlaymentById(@PathVariable("id") int Id) {
        Playment result= playmentService.getPlaymentById(Id);
        return new CommonResult<Object>(200, "Query Ok by:"+ serverPort , result);
    }

    @PostMapping(value = "/playment/create")
    public CommonResult<?> CreatePlayment(@RequestBody Playment playment) {
        int result = playmentService.create(playment);
        return new CommonResult<Object>(200,"Create Ok by:"+ serverPort , result);
    }



}
