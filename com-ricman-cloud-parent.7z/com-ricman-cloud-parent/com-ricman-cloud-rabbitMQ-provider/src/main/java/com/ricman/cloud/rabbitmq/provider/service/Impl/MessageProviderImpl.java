package com.ricman.cloud.rabbitmq.provider.service.Impl;

import com.ricman.cloud.rabbitmq.provider.service.IMessageProvider;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;

import javax.annotation.Resource;
import java.util.UUID;

/**
 * @Author m93349
 * @Date 2020/10/20 10:05
 * @Version 1.0
 */
@EnableBinding(Source.class)
public class MessageProviderImpl implements IMessageProvider {

    @Resource
    private MessageChannel output;

    @Override
    public String Send() {
        String UUID = java.util.UUID.randomUUID().toString();
        output.send(MessageBuilder.withPayload(UUID).build());
        System.out.println("send " + UUID);
        return null;
    }
}
