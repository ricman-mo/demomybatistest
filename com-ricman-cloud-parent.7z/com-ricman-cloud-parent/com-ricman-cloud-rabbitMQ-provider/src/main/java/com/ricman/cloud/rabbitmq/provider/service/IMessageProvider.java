package com.ricman.cloud.rabbitmq.provider.service;

/**
 * @Author m93349
 * @Date 2020/10/20 10:04
 * @Version 1.0
 */
public interface IMessageProvider {
   public String Send();
}
