package com.ricman.cloud.hystrix.controller;

import com.ricman.cloud.hystrix.service.ProviderPlaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/15 13:53
 * @Version 1.0
 */

@RestController
public class PlaymentController {

    @Autowired
    private ProviderPlaymentService playmentService;

    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/playment/hystrix/ok/{id}")
    public String GetOk(@PathVariable("id") int id) {
        System.out.println("get OK" + serverPort + "Thread " + Thread.currentThread().getName() + "ID " + id);
        return playmentService.GetOk(id);
    }

    @GetMapping("/playment/hystrix/timeout/{id}")
    public String GetTimeOut(@PathVariable("id") int id) {
        System.out.println("get GetTimeOut" + serverPort + "Thread " + Thread.currentThread().getName() + "ID " + id);
        return playmentService.GetTimeOut(id);
    }

    @GetMapping("/playment/hystrix/circuit/{id}")
    public String GetCircuit(@PathVariable("id") int id) {
        System.out.println("get CircuitBreaker" + serverPort + "Thread " + Thread.currentThread().getName() + "ID " + id);
        return playmentService.CircuitBreaker(id);
    }
}
