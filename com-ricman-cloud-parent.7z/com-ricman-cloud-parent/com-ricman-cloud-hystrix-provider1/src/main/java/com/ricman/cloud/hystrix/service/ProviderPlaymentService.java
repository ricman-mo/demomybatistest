package com.ricman.cloud.hystrix.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.springframework.cloud.commons.util.IdUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Random;
import java.util.UUID;

/**
 * @Author m93349
 * @Date 2020/10/15 13:50
 * @Version 1.0
 */
@Service
public class ProviderPlaymentService {

    public String GetOk(int id) {
         return "Hystrix OK" + id + "Thread: " + Thread.currentThread().getName();
    }

    @HystrixCommand(fallbackMethod = "GetTimeoutHandler", commandProperties = {
            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "3000")
    })
    public String GetTimeOut(@PathVariable("id") int id) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "Hystrix Timeout 3000 OK" + id + "Thread: " + Thread.currentThread().getName();
    }

    public String GetTimeoutHandler(@PathVariable("id") int id) {
        return "Hystrix Timeout 3000 Timeout" + id + "Thread: " + Thread.currentThread().getName();
    }

    @HystrixCommand(fallbackMethod = "CircuitBreakerFallBack", commandProperties = {
            @HystrixProperty(name = "circuitBreaker.enabled",value = "true"),  //是否开启断路器
            @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold",value = "10"),   //请求次数
            @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds",value = "10000"),  //时间范围
            @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage",value = "60"), //失败率达到多少后跳闸


    })
    public String CircuitBreaker(@PathVariable("id") int id) {
        if(id <0) {
            throw new RuntimeException("ID 不能小于0");
        }
        return "调用成功 id=" + id  + "流水号： " + UUID.randomUUID().toString();

    }

    public String CircuitBreakerFallBack(@PathVariable("id") int id) {
        return "ID 不能小于0， 当前ID是" + id;
    }


}
