package com.ricman.cloud.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @Author m93349
 * @Date 2020/10/16 14:49
 * @Version 1.0
 */
@Component
public class GatewayConfig {

    @Bean
    public RouteLocator getRouteLocator(RouteLocatorBuilder builder) {
        RouteLocatorBuilder.Builder routeBuilder = builder.routes();
        routeBuilder.route("tesss", r->r.path("/guonei").uri("http://www.baidu.com/guonei")).build();
        return routeBuilder.build();
    }
}
