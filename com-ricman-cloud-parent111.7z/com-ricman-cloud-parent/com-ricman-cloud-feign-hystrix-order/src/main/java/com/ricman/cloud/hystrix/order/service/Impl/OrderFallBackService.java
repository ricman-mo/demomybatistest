package com.ricman.cloud.hystrix.order.service.Impl;

import com.ricman.cloud.hystrix.order.service.IOrderPlaymentService;
import org.springframework.stereotype.Component;

/**
 * @Author m93349
 * @Date 2020/10/16 9:45
 * @Version 1.0
 */
@Component
public class OrderFallBackService implements IOrderPlaymentService {
    public String GetOk(int id) {
        return "统一处理降级，请求繁忙，请稍后再试!";
    }

    public String GetTimeOut(int id) {
        return "统一处理降级，请求繁忙，请稍后再试!";
    }
}
