package com.ricman.cloud.sentinel.handler;

import org.springframework.stereotype.Component;

/**
 * @Author m93349
 * @Date 2020/10/22 10:30
 * @Version 1.0
 */
@Component
public class CustomSentinelLimitHandler {
    public static String HandlerException() {
        return "错误，被全局限流使用---1";
    }

    public static String HandlerException1() {
        return "错误，被全局限流使用 ---2";
    }
}
