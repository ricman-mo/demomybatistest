package com.ricman.cloud.sentinel.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.ricman.cloud.sentinel.handler.CustomSentinelLimitHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/21 16:13
 * @Version 1.0
 */
@RestController
public class HelloController {

    @GetMapping("A")
    @SentinelResource(value = "A", blockHandlerClass = CustomSentinelLimitHandler.class,
    blockHandler = "HandlerException1")
    public String SayA() {
      return "this is get A";
    }
    @GetMapping("B")
    @SentinelResource(value = "A", blockHandlerClass = CustomSentinelLimitHandler.class,
            blockHandler = "HandlerException2")
    public String SayB() {
        return "this is get B";
    }
}
