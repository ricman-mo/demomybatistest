package com.ricman.cloud.comsumer.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * @Author m93349
 * @Date 2020/10/20 14:55
 * @Version 1.0
 */
@RestController
@Slf4j
public class HelloController {

    @Value("${service-url.nacos-user-service}")
    private String nacasUrl;

    @Autowired
    private RestTemplate restTemplate;


    @GetMapping("/comsumer/hello")
    public String SayHello() {
        String Id = UUID.randomUUID().toString();
        System.out.println("ID=" +Id);
        return  restTemplate.getForObject(nacasUrl + "/hello/" + Id, String.class);
    }
}
