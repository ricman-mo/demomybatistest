package com.ricman.cloud.rabbitmq.comsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author m93349
 * @Date 2020/10/20 9:56
 * @Version 1.0
 */
@SpringBootApplication
public class Comsumer8803Application {
    public static void main(String[] args) {
        SpringApplication.run(Comsumer8803Application.class, args);
    }
}
