package com.ricman.cloud.utility;

import com.ricman.cloud.utility.Entitys.Season2;

/**
 * @Author m93349
 * @Date 2020/10/22 13:15
 * @Version 1.0
 */
public class Application {
    private static Season2 spring = new Season2("cx","xxx");
    private static Season2 summer = new Season2("xt","xxx");
    private static Season2 autumn = new Season2("qt","xxx");
    private static  Season2 winter = new Season2("dt","xxx");
    public static void main(String[] args) {
        System.out.println(spring.toString());
        System.out.println(summer.toString());
        System.out.println(autumn.toString());
        System.out.println(winter.toString());
    }
}
