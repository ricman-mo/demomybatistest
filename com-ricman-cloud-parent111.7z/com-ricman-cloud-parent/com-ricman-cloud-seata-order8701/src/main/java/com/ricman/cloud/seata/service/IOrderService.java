package com.ricman.cloud.seata.service;

import com.ricman.cloud.seata.entitys.Order;
import org.apache.ibatis.annotations.Param;

/**
 * @Author m93349
 * @Date 2020/10/23 13:44
 * @Version 1.0
 */
public interface IOrderService {
    void Create(Order order);

    void UpdateOrderStatus(@Param("userid")long userId, @Param("status")long status);
}
