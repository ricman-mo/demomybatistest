package com.ricman.cloud.seata.service;

import com.ricman.cloud.seata.entitys.CommonResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @Author m93349
 * @Date 2020/10/23 14:08
 * @Version 1.0
 */
@FeignClient(value = "com-ricman-cloud-nacos-seata-product-service")
public interface StorageService {
    @GetMapping("/product/decrease")
    public CommonResult<String> decrease(@RequestParam("productId") int productId, @RequestParam("count")int count);
}
