package com.ricman.cloud.seata.service.Impl;

import com.ricman.cloud.seata.dao.OrderDao;
import com.ricman.cloud.seata.entitys.Order;
import com.ricman.cloud.seata.service.AccountService;
import com.ricman.cloud.seata.service.IOrderService;
import com.ricman.cloud.seata.service.StorageService;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Author m93349
 * @Date 2020/10/23 14:06
 * @Version 1.0
 */
@Service
public class OrderService implements IOrderService {

    @Resource
    private OrderDao orderDao;

    @Resource
    private AccountService accountService;

    @Resource
    private StorageService storageService;

    @GlobalTransactional
    public void Create(Order order) {
        System.out.println("1.创建定单");
        orderDao.Create(order);
        System.out.println("1.创建定单完成");
        System.out.println("2.扣减库存开始");
        storageService.decrease(order.getProductId(), order.getCount());
        System.out.println("2.扣减库存完成");
        System.out.println("3.账户金额扣减开始");
        accountService.decrease(order.getUserId(), order.getMoney());
        System.out.println("3.账户金额扣减完成");
        System.out.println("4.修改订单状态开始");
        orderDao.UpdateOrderStatus(order.getUserId(), 0);
        System.out.println("4.修改订单状态完成");
    }

    public void UpdateOrderStatus(long userId, long status) {

    }
}
