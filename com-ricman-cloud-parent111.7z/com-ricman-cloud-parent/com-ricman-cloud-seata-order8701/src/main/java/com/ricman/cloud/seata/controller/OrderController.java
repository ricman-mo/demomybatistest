package com.ricman.cloud.seata.controller;

import com.ricman.cloud.seata.entitys.CommonResult;
import com.ricman.cloud.seata.entitys.Order;
import com.ricman.cloud.seata.service.Impl.OrderService;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/23 14:23
 * @Version 1.0
 */
@RestController
public class OrderController {
    @Autowired
    private OrderService orderservice;

    @GetMapping("order/create")
    public CommonResult<String> create(@RequestBody Order order) {
        orderservice.Create(order);
        return new CommonResult<String>(200, "创建成功 ");
    }
}
