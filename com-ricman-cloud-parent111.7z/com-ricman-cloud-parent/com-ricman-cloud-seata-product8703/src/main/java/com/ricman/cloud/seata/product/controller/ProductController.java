package com.ricman.cloud.seata.product.controller;

import com.ricman.cloud.seata.product.entitys.CommonResult;
import com.ricman.cloud.seata.product.entitys.Product;
import com.ricman.cloud.seata.product.service.IProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Author m93349
 * @Date 2020/10/26 10:30
 * @Version 1.0
 */
@RestController
@Slf4j
public class ProductController {

    @Resource
    private IProductService productService;

    @GetMapping("/product/decrease")
    public CommonResult<String> decrease(@RequestParam("productId") int productId, @RequestParam("count")int count) {

        Product product = productService.selectById(productId);
        if (product == null) {
            log.info("没有此产品 productId = " + productId);
            throw new RuntimeException("没有此产品");
        }
        if (product.getResidue() > count) {
            productService.decrease(productId, count);
        } else {
            log.info("可用数量不足 productId = " + productId);
            throw new RuntimeException("可用数量不足！");
        }
        return new CommonResult<String>(200, "扣减成功!");
    }

}
