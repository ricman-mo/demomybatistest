package com.ricman.cloud.nacos.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author m93349
 * @Date 2020/10/20 15:23
 * @Version 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class NacosConfigApplication3377 {
    public static void main(String[] args) {
        SpringApplication.run(NacosConfigApplication3377.class, args);
    }
}
