package com.ricman.cloud.dao;

import com.ricman.cloud.entitys.Playment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PlaymentDao {

    public int create(Playment playment);

    public Playment getPlaymentById(@Param("id") long id);
}
