package com.ricman.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author m93349
 * @Date 2020/10/14 10:47
 * @Version 1.0
 */
@SpringBootApplication
public class ProviderZookeeperServer {
    public static void main(String[] args) {
        SpringApplication.run(ProviderZookeeperServer.class, args);
    }
}
