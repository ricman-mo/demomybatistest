package com.ricman.cloud.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/14 10:54
 * @Version 1.0
 */
@RestController
public class ZookeeperController {

    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/zookeeper")
    public String TestZookeeper() {
        return "Hello Zookeeper" + serverPort;
    }
}
