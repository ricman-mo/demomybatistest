package com.ricman.cloud.controller;

import com.ricman.cloud.service.IHelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/15 10:15
 * @Version 1.0
 */
@RestController
public class HelloController {
    @Autowired
   private IHelloService helloService;

    @GetMapping("/hello")
    public String SayHello() {
        return helloService.SayHello();
    }

    @GetMapping("/longtime")
    public String TimeOut() {
        return helloService.TestTimeout();
    }
}
