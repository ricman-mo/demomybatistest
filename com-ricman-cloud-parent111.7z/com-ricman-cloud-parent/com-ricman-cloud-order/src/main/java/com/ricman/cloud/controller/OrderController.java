package com.ricman.cloud.controller;

import com.ricman.cloud.entitys.CommonResult;
import com.ricman.cloud.entitys.Playment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class OrderController {
    public static final String URL="http://COM-RICMAN-CLOUD-PROVIDER";
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/playment/create")
    public CommonResult<?> CreatePlayment(Playment playment) {
        return restTemplate.postForObject(URL + "/playment/create/", playment, CommonResult.class);
    }

    @GetMapping("/playment/get/{id}")
    public CommonResult<?> getPlayment(@PathVariable("id") int id) {
        return restTemplate.getForObject(URL+ "/playment/get/" + id, CommonResult.class);
    }

    public ResponseEntity<?> getEntity(@PathVariable("id") int id){
        return  restTemplate.getForEntity(URL+ "/playment/get/" + id, CommonResult.class);
    }
}
