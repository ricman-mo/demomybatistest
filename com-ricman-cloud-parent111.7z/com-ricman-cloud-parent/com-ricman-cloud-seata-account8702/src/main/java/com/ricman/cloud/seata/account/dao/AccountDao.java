package com.ricman.cloud.seata.account.dao;

import com.ricman.cloud.seata.account.entitys.Account;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Author m93349
 * @Date 2020/10/26 10:53
 * @Version 1.0
 */
@Mapper
public interface AccountDao {
    public int decrease(@Param("id")int id, @Param("count")int count);
    public Account selectById(int id);
}
