package com.ricman.cloud.rabbitmq.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author m93349
 * @Date 2020/10/20 9:57
 * @Version 1.0
 */
@SpringBootApplication
public class Provider8801Application {
    public static void main(String[] args) {
        SpringApplication.run(Provider8801Application.class, args);
    }
}
