package com.ricman.cloud.rabbitmq.provider.controller;

import com.netflix.discovery.converters.Auto;
import com.ricman.cloud.rabbitmq.provider.service.Impl.MessageProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author m93349
 * @Date 2020/10/20 10:15
 * @Version 1.0
 */
@RestController
public class SendMessageController {

    @Autowired
    private MessageProviderImpl messageProvider;

    @GetMapping("/sendMessage")
    public String SendMessage() {
        return messageProvider.Send();
    }


    @GetMapping("/hello")
    public String SayHello() {
        return "8801 is OK";
    }
}
